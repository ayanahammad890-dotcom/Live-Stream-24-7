package com.liveloop.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import androidx.compose.runtime.mutableStateOf
import com.pedro.encoder.input.decoder.AudioDecoderInterface
import com.pedro.encoder.input.decoder.VideoDecoderInterface
import com.pedro.rtmp.utils.ConnectCheckerRtmp
import com.pedro.rtplibrary.rtmp.RtmpFromFile

object StreamState {
    val running = mutableStateOf(false)
    val live = mutableStateOf(false)
    val status = mutableStateOf("Offline")
    val videoName = mutableStateOf("")
}

class StreamService : Service(), ConnectCheckerRtmp, VideoDecoderInterface, AudioDecoderInterface {
    private var stream: RtmpFromFile? = null
    private var wake: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var url = ""
    private var path = ""
    private var loop = true
    private var wanted = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == "STOP") { shutdown(); return START_NOT_STICKY }
        url = i.getStringExtra("url") ?: ""
        path = i.getStringExtra("path") ?: ""
        loop = i.getBooleanExtra("loop", true)
        wanted = true
        startFg()
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "liveloop:stream").also { it.acquire() }
        }
        begin()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("live", "Live stream", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, StreamService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "live")
            .setContentTitle("LiveLoop is streaming")
            .setContentText("Tap to open")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun begin() {
        if (!wanted) return
        try {
            stream?.let { try { if (it.isStreaming) it.stopStream() } catch (_: Exception) {} }
            val s = RtmpFromFile(this, this, this)
            s.setLoopMode(loop)
            if (s.prepareVideo(path) && s.prepareAudio(path)) {
                stream = s
                StreamState.status.value = "Connecting..."
                s.startStream(url)
            } else {
                StreamState.status.value = "Video not supported (needs video + audio)"
                shutdown(keepStatus = true)
            }
        } catch (e: Exception) {
            StreamState.status.value = "Error: " + (e.message ?: "unknown")
            retry()
        }
    }

    private fun retry() {
        if (!wanted) return
        StreamState.live.value = false
        StreamState.status.value = "Reconnecting..."
        h.postDelayed({ begin() }, 5000)
    }

    private fun shutdown(keepStatus: Boolean = false) {
        wanted = false
        h.removeCallbacksAndMessages(null)
        try { stream?.let { if (it.isStreaming) it.stopStream() } } catch (_: Exception) {}
        stream = null
        try { wake?.release() } catch (_: Exception) {}
        wake = null
        StreamState.running.value = false
        StreamState.live.value = false
        if (!keepStatus) StreamState.status.value = "Offline"
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() { shutdown(keepStatus = true); super.onDestroy() }

    // RTMP callbacks
    override fun onConnectionStartedRtmp(rtmpUrl: String) {}
    override fun onConnectionSuccessRtmp() {
        StreamState.live.value = true
        StreamState.status.value = "Live"
    }
    override fun onConnectionFailedRtmp(reason: String) { h.post { retry() } }
    override fun onNewBitrateRtmp(bitrate: Long) {}
    override fun onDisconnectRtmp() { if (wanted) h.post { retry() } }
    override fun onAuthErrorRtmp() { StreamState.status.value = "Auth error - check stream key" }
    override fun onAuthSuccessRtmp() {}

    // Decoder callbacks (video finished when loop is off)
    override fun onVideoDecoderFinished() { if (!loop) h.post { shutdown() } }
    override fun onAudioDecoderFinished() {}
}

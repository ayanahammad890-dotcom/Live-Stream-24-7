package com.liveloop.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

val Blue = Color(0xFF3B5BDB)
val Bg = Color(0xFFF7F8FF)
val Ink = Color(0xFF1A1D2E)
val Grey = Color(0xFF9AA0AE)
val Grad = Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF5B45E0)))

val platforms = listOf(
    "YouTube" to "rtmp://a.rtmp.youtube.com/live2/",
    "Facebook" to "rtmps://live-api-s.facebook.com:443/rtmp/",
    "Twitch" to "rtmp://live.twitch.tv/app/",
    "Custom RTMP (paste full URL)" to ""
)

class Form {
    var platform by mutableIntStateOf(0)
    var title by mutableStateOf("")
    var key by mutableStateOf("")
    var loop by mutableStateOf(true)
    var selected by mutableStateOf<File?>(null)
}

fun videoDir(c: Context) = File(c.filesDir, "videos").also { it.mkdirs() }
fun listVideos(c: Context): List<File> =
    videoDir(c).listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
fun niceName(f: File) = f.name.substringAfter("_")

suspend fun importVideo(c: Context, uri: Uri): File = withContext(Dispatchers.IO) {
    var name = "video.mp4"
    c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) name = cur.getString(i)
    }
    val f = File(videoDir(c), "${System.currentTimeMillis()}_$name")
    c.contentResolver.openInputStream(uri)!!.use { inp -> f.outputStream().use { inp.copyTo(it) } }
    f
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    val videos = remember { mutableStateListOf<File>().also { it.addAll(listVideos(ctx)) } }
    val form = remember { Form() }
    var dialog by remember { mutableStateOf<Pair<String, String>?>(null) }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            try {
                val f = importVideo(ctx, uri)
                videos.add(0, f)
                form.selected = f
                toast("Video added")
            } catch (e: Exception) { toast("Could not add video") }
        }
    }

    fun goLive() {
        val f = form.selected
        val k = form.key.trim()
        if (k.isEmpty()) { toast("Enter your stream key"); return }
        if (f == null) { toast("Select a video first"); return }
        val base = platforms[form.platform].second
        val url = if (base.isEmpty()) k else base + k
        val i = Intent(ctx, StreamService::class.java)
            .putExtra("url", url).putExtra("path", f.absolutePath).putExtra("loop", form.loop)
        ContextCompat.startForegroundService(ctx, i)
        StreamState.running.value = true
        StreamState.status.value = "Connecting..."
        StreamState.videoName.value = niceName(f)
        tab = 2
    }

    fun stopLive() {
        ctx.startService(Intent(ctx, StreamService::class.java).setAction("STOP"))
    }

    val helpText = "1. Upload a video (it must have sound).\n2. Open the Stream tab, choose the platform, paste your Stream Key and pick the video.\n3. Tap Go Live Now.\n\nKeep the phone charging and connected to the internet. The stream reconnects automatically if the internet drops. In phone settings, set battery usage for this app to Unrestricted so it keeps running."

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 140.dp)
        ) {
            when (tab) {
                0 -> HomeScreen(
                    onStream = { tab = 1 }, onUpload = { picker.launch("video/*") },
                    onHelp = { dialog = "How to use the app" to helpText }
                )
                1 -> StreamScreen(form, videos, { picker.launch("video/*") }, ::goLive)
                2 -> LiveScreen({ tab = 1 }, ::stopLive)
                3 -> VideosScreen(videos, form, { picker.launch("video/*") }) { f ->
                    f.delete(); videos.remove(f); if (form.selected == f) form.selected = null
                }
                else -> SettingsScreen(
                    onSoon = { toast("Coming soon") },
                    onHelp = { dialog = "Help & Support" to helpText },
                    onPrivacy = { dialog = "Privacy Policy" to "This app works only on your phone. Your videos and stream key are never uploaded to any server of ours; the stream goes directly from your phone to the platform you choose." },
                    onTerms = { dialog = "Terms & Conditions" to "Use this app only with videos you have the right to broadcast, and follow the rules of the streaming platform you use." }
                )
            }
        }
        BottomBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding())
    }

    dialog?.let { (t, m) ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton({ dialog = null }) { Text("OK") } },
            title = { Text(t) }, text = { Text(m) }
        )
    }
}

@Composable
fun Header(small: String?, big: String) {
    if (small != null) Text(small, fontSize = 18.sp, color = Grey, fontWeight = FontWeight.Medium)
    Text(big, fontSize = 34.sp, color = Ink, fontWeight = FontWeight.ExtraBold)
    Spacer(Modifier.height(20.dp))
}

@Composable
fun CardBox(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    var m = modifier.fillMaxWidth().shadow(4.dp, shape).background(Color.White, shape).clip(shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(20.dp), content = content)
}

@Composable
fun ActionCard(icon: ImageVector, tint: Color, bg: Color, title: String, sub: String, onClick: () -> Unit) {
    CardBox(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).background(bg, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(sub, fontSize = 15.sp, color = Grey)
            }
        }
    }
    Spacer(Modifier.height(16.dp))
}

@Composable
fun GradButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(30.dp)).background(Grad).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
}

@Composable
fun StatusPill() {
    val running = StreamState.running.value
    val live = StreamState.live.value
    val (txt, col) = when {
        live -> "LIVE" to Color(0xFF16A34A)
        running -> "Connecting" to Color(0xFFF59E0B)
        else -> "Offline" to Color(0xFFDC2626)
    }
    Box(Modifier.background(col, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 10.dp)) {
        Text(txt, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun HomeScreen(onStream: () -> Unit, onUpload: () -> Unit, onHelp: () -> Unit) {
    Header("Welcome Back!", "Your Dashboard")
    CardBox {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Stream Status", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            StatusPill()
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (StreamState.running.value) "Streaming: ${StreamState.videoName.value}\n${StreamState.status.value}"
            else "You have no active streams.",
            fontSize = 18.sp, color = Grey
        )
    }
    Spacer(Modifier.height(28.dp))
    Text("Quick Actions", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
    Spacer(Modifier.height(16.dp))
    ActionCard(Icons.Filled.Sensors, Blue, Color(0xFFDCE8FF), "Start New Stream", "Go live with a pre-recorded video", onStream)
    ActionCard(Icons.Filled.CloudUpload, Color(0xFF16A34A), Color(0xFFDDF8E6), "Upload Video", "Add a new video to your library", onUpload)
    ActionCard(Icons.Filled.PlayCircle, Color(0xFF9333EA), Color(0xFFF1E4FD), "How to use the app?", "Read quick tutorial", onHelp)
}

@Composable
fun StreamScreen(form: Form, videos: List<File>, onPick: () -> Unit, onLive: () -> Unit) {
    var pOpen by remember { mutableStateOf(false) }
    var vOpen by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    CardBox {
        Text("Select Platform", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(
                { pOpen = true }, Modifier.fillMaxWidth().height(60.dp), shape = shape
            ) {
                Text(platforms[form.platform].first, fontSize = 20.sp, color = Ink, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.ArrowDropDown, null, tint = Ink)
            }
            DropdownMenu(pOpen, { pOpen = false }) {
                platforms.forEachIndexed { i, p ->
                    DropdownMenuItem({ Text(p.first) }, { form.platform = i; pOpen = false })
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Stream Title", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            form.title, { form.title = it }, Modifier.fillMaxWidth(), shape = shape, singleLine = true,
            placeholder = { Text("My 24/7 Lo-Fi Stream") }
        )
        Spacer(Modifier.height(18.dp))
        Text("Stream Key", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            form.key, { form.key = it }, Modifier.fillMaxWidth(), shape = shape, singleLine = true,
            placeholder = { Text(if (platforms[form.platform].second.isEmpty()) "rtmp://..." else "XXXX-XXXX-XXXX") },
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton({ show = !show }) {
                    Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                }
            }
        )
        Text("Your key stays on your phone. Field is masked.", fontSize = 14.sp, color = Grey, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(18.dp))
        Text("Select Video", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(
                { if (videos.isEmpty()) onPick() else vOpen = true }, Modifier.fillMaxWidth().height(60.dp), shape = shape
            ) {
                Icon(Icons.Filled.Videocam, null, tint = Ink)
                Spacer(Modifier.width(12.dp))
                Text(form.selected?.let { niceName(it) } ?: "Select a Video...", fontSize = 18.sp, color = if (form.selected == null) Grey else Ink,
                    maxLines = 1, modifier = Modifier.weight(1f))
            }
            DropdownMenu(vOpen, { vOpen = false }) {
                videos.forEach { f -> DropdownMenuItem({ Text(niceName(f), maxLines = 1) }, { form.selected = f; vOpen = false }) }
                DropdownMenuItem({ Text("+ Add new video") }, { vOpen = false; onPick() })
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Loop Video 24/7", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
            Switch(form.loop, { form.loop = it })
        }
        Spacer(Modifier.height(22.dp))
        GradButton("Go Live Now", onLive)
    }
}

@Composable
fun LiveScreen(onStart: () -> Unit, onStop: () -> Unit) {
    Header(null, "Active Streams")
    CardBox {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!StreamState.running.value) {
                Icon(Icons.Filled.LiveTv, null, tint = Color(0xFFCBD0D8), modifier = Modifier.size(100.dp))
                Spacer(Modifier.height(16.dp))
                Text("All Streams Offline", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(8.dp))
                Text("You have no active streams. Start one from the \"Stream\" tab.", color = Grey, fontSize = 18.sp)
                Spacer(Modifier.height(24.dp))
                GradButton("Start a New Stream", onStart)
            } else {
                StatusPill()
                Spacer(Modifier.height(16.dp))
                Text(StreamState.videoName.value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 2)
                Spacer(Modifier.height(6.dp))
                Text(StreamState.status.value, fontSize = 18.sp, color = Grey)
                Spacer(Modifier.height(24.dp))
                Box(
                    Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(30.dp))
                        .background(Color(0xFFDC2626)).clickable { onStop() },
                    contentAlignment = Alignment.Center
                ) { Text("Stop Stream", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            }
        }
    }
}

@Composable
fun VideosScreen(videos: List<File>, form: Form, onPick: () -> Unit, onDelete: (File) -> Unit) {
    Header(null, "My Videos")
    GradButton("Upload Video", onPick)
    Spacer(Modifier.height(16.dp))
    if (videos.isEmpty()) Text("No videos yet.", color = Grey, fontSize = 18.sp)
    videos.forEach { f ->
        CardBox(onClick = { form.selected = f }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VideoLibrary, null, tint = Blue, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(niceName(f), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink, maxLines = 2)
                    Text(
                        (if (form.selected == f) "Selected  |  " else "") + "%.1f MB".format(f.length() / 1048576.0),
                        color = if (form.selected == f) Blue else Grey, fontSize = 14.sp
                    )
                }
                IconButton({ onDelete(f) }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFDC2626)) }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SettingsScreen(onSoon: () -> Unit, onHelp: () -> Unit, onPrivacy: () -> Unit, onTerms: () -> Unit) {
    Header(null, "Settings")
    ActionCard(Icons.Filled.CreditCard, Blue, Color(0xFFDCE8FF), "Billing & Subscription", "Manage your subscription plan", onSoon)
    ActionCard(Icons.Filled.CardGiftcard, Color(0xFF16A34A), Color(0xFFDDF8E6), "Refer & Earn", "Invite friends and earn rewards", onSoon)
    ActionCard(Icons.Filled.Info, Color(0xFF16A34A), Color(0xFFDDF8E6), "Help & Support", "How to use the app", onHelp)
    ActionCard(Icons.Filled.Lock, Blue, Color(0xFFDCE8FF), "Privacy Policy", "Read our privacy policy", onPrivacy)
    ActionCard(Icons.Filled.Description, Blue, Color(0xFFDCE8FF), "Terms & Conditions", "Read our terms of service", onTerms)
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val items = listOf(
        "Home" to Icons.Filled.Home, "Stream" to Icons.Filled.Sensors, "Live" to Icons.Filled.Podcasts,
        "Videos" to Icons.Filled.VideoLibrary, "Settings" to Icons.Filled.Settings
    )
    val shape = RoundedCornerShape(36.dp)
    Row(
        modifier.fillMaxWidth().padding(12.dp).shadow(12.dp, shape).background(Color.White, shape).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val sel = i == tab
            Column(Modifier.clickable { onTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(54.dp).clip(CircleShape).then(if (sel) Modifier.background(Grad) else Modifier),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = if (sel) Color.White else Grey) }
                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) Blue else Grey)
            }
        }
    }
}
